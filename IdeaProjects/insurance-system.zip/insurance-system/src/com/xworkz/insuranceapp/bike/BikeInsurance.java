package com.xworkz.insuranceapp.bike;

import com.xworkz.insuranceapp.Insurance;

public class BikeInsurance extends Insurance {

    public void claim()
    {
        System.out.println("Bike insurance started");
        System.out.println("Claim with premium amount 538");
        System.out.println("Bike insurance ended");
        System.out.println("-----------------------------------------------------------");
    }
}
