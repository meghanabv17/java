package com.xworkz.insuranceapp.car;

import com.xworkz.insuranceapp.Insurance;

public class CarInsurance extends Insurance {
    public void claim()
    {
        System.out.println("Car insurance started");
        System.out.println("Claim with premium amount 2039");
        System.out.println("Car insurance ended");
        System.out.println("--------------------------------------------------------------");
    }

}
