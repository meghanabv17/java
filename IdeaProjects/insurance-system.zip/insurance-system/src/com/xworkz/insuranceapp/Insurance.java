package com.xworkz.insuranceapp;

import com.xworkz.insuranceapp.bike.BikeInsurance;

public class Insurance {

    public void claim()
    {
        System.out.println("Insurance started");
        System.out.println("Claim a premium");
        System.out.println("Insurance ended");
        System.out.println("------------------------------------------------------------");
    }
}
