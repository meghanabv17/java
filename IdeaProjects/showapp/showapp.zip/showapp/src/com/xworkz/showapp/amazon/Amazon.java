package com.xworkz.showapp.amazon;

public interface Amazon  {

    int miniBooking();
}
