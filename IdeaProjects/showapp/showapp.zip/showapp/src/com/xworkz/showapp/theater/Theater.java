package com.xworkz.showapp.theater;

public interface Theater {

    int miniBooking();
}
