package com.xworkz.showapp.paytm;

public interface Paytm {

    int miniBooking();
}
