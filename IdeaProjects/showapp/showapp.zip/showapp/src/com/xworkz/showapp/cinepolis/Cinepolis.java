package com.xworkz.showapp.cinepolis;

import com.xworkz.showapp.bookmyshow.BookMyShow;

public class Cinepolis implements BookMyShow {


    @Override
    public int miniBooking() {
        return 56;
    }
}
