package com.xworkz.showapp.bookmyshow;

public interface BookMyShow {

    int miniBooking();
    String ownerName = "baba";

}
