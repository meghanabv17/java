package com.xworkz.productapp.dao;

import com.xworkz.productapp.dto.ProductDto;

public interface EcommerceDao {

    boolean addProducts(ProductDto productDto);


}
