package com.xworkz.productapp.dao;

import com.xworkz.productapp.dto.ProductDto;

import javax.security.auth.login.Configuration;

public class EcommerceDaoImpl implements EcommerceDao {

    @Override
    public boolean addProducts(ProductDto productDto) {


        return false;
    }
}
