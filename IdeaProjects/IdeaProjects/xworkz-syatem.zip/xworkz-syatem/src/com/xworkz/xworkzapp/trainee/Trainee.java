package com.xworkz.xworkzapp.trainee;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Trainee{

    private String traineeName;
    private int TraineeId;
    private String Address;
    private long phoneNo;
    private String usn;
}
