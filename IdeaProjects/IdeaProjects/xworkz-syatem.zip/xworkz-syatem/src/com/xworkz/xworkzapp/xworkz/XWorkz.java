package com.xworkz.xworkzapp.xworkz;

import com.xworkz.xworkzapp.trainee.Trainee;

public interface XWorkz {

    boolean trainee(Trainee trainee);
    void getTraineeDetails();
    boolean updateTraineeDetails();
    boolean deleteTraineeDetails();
}
