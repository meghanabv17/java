package com.xworkzk.jobapp.employee;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString

public class Employee {

    private int employeeId;
    private String employeeName;
    private String bloodGroup;
    private String address;
}
